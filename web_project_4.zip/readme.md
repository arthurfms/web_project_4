# Projeto 4: Around The U.S.

Projeto do Sprint 4, do curso de Desenvolvimento Web da Practicum by Yandex. O projeto consiste em criar uma rede social onde o usuário pode editar seus dados (nome e trabalho), adicionar, deletar e interagir com diferentes cards de imagem.
[Link para o projeto](https://arthurfms.github.io/web_project_4)
Neste projeto foram utilizados os seguintes conhecimentos:

- HTML
- CSS
- JavaScript
- Git
- Metodologia BEM
