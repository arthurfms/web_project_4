// webpack.config.js
const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
  devtool: "inline-source-map",
  entry: {
    main: "./src/page/index.js",
  },
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "main.js",
    publicPath: "",
  },
  target: ["web", "es5"],
  stats: { children: true },
  mode: "development",
  devServer: {
    static: path.resolve(__dirname, "./dist"),
    compress: true,
    port: 8080,
    open: true,
  },
  module: {
    rules: [
      // esse é um vetor de regras
      // adicione um objeto contendo regras para Babel nele
      {
        // uma expressão regular que busca por todos os arquivos js
        test: /\.js$/,
        // todos os arquivos devem ser processados pelo babel-loader
        loader: "babel-loader",
        // exclua a pasta node_modules, não precisamos processar os arquivos nela
        exclude: "/node_modules/",
      },
      {
        test: /\.css$/,
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: "css-loader",
            options: {
              importLoaders: 1,
            },
          },
          "postcss-loader",
        ],
      },
      {
        // adicione a regra para processar arquivos
        test: /\.(png|svg|jpg|gif|woff(2)?|eot|ttf|otf)$/,
        type: "asset/resource",
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./src/index.html", // caminho para nosso arquivo index.html
    }),
    new CleanWebpackPlugin(),
    new MiniCssExtractPlugin(), // conecte o plugin para unir os arquivos CSS
  ],
};
