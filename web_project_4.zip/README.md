# Projeto 4: Around The U.S.

Projeto do Sprint 4, do curso de Desenvolvimento Web da Practicum by Yandex.
[Link para o projeto](https://arthurfms.github.io/web_project_4)
Neste projeto foram utilizados os seguintes conhecimentos:

- HTML
- CSS
- JavaScript
- Git
- Metodologia BEM
